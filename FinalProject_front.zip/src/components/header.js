import Menu from "./menu";

function header() {
  return (
    <header className="header">
      <Menu />
    </header>
  );
}

export default header;