import Menu from "./Menu";
import { useState } from "react";

function Header() {
  
  return (
    <header className="header">
     
      <Menu />
    </header>
  );
}

export default Header;