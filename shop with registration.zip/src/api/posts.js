const posts = [
  {
    title: "Best flowers for inside home",
    describe:
      "From personal experience, receiving flowers always manages to put a smile on my face. That’s why we continue giving and receiving these flowering plants because it improves our mood",
    imgUrl: "images/image1.jpg",
  },
  {
    title: "Best flowers for inside home",
    describe:
      "Another exciting benefit of having them surround you is that it increases creativity. If you handle a team that needs a little inspiration and you’re reading this, consider adding a flower bouquet to your workspace.",
    imgUrl: "images/Rectangle 56.jpg",
  },
  {
    title: "Best flowers for inside home",
    describe:
      "When you keep them in your home, you provide care and attention that only humans can do. And when they are cared for, they reward their human with more beauty. This is the kind of nurturing process that creates positive human emotions.",
    imgUrl: "images/image3.jpg",
  },
];

export default posts;
