const bestseler = [
  {
    title: "Daisy",
    imgUrl: "images/Rectangle 58.jpg",
  },
  {
    title: "Sun flower",
    imgUrl: "images/Rectangle 58 (1).jpg",
  },
  {
    title: "White Rose",
    imgUrl: "images/Rectangle 58 (2).jpg",
  },
  {
    title: "Periwinkle",
    imgUrl: "images/Rectangle 58 (3).jpg",
  },
];

export default bestseler;
