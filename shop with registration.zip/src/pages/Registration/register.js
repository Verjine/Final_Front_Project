import React from "react";
import Menu from "../../components/Menu";
import { useForm } from "react-hook-form";
import { Link } from "react-router-dom";

function Register() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (data) =>
    fetch("http://localhost:5000/user/register", {
      method: "POST",
      body: JSON.stringify({
        username: data.username,
        email: data.email,
        password: data.password,
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        // Handle data
      })
      .catch((err) => {
        console.log(err.message);
      });

  return (
    <section>
      <div>
        <Menu />
      </div>
      <div className="register">
        <div className="col-1">
          <h2>Create Account</h2>
          <span>Register and help us help you</span>

          <form
            id="form"
            className="flex flex-col"
            onSubmit={handleSubmit(onSubmit)}
          >
            <input
              className="input"
              type="text"
              {...register("username")}
              placeholder="username"
            />
            <input
              className="input"
              type="text"
              {...register("email")}
              placeholder="email"
            />

            <input
              className="input"
              type="text"
              {...register("password")}
              placeholder="password"
            />
            <button className="btn">Register</button>
            <div className="text">
              <p>
                Already have an account ?
                <Link to="/login">
                  {" "}
                  <span> Login</span>{" "}
                </Link>
              </p>
            </div>
          </form>
        </div>
        <div className="col-2">
          <img src="/images/registerflower.jpg" alt="" />
        </div>
      </div>
    </section>
  );
}

export default Register;
