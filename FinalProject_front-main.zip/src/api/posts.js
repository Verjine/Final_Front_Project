const posts = [
  {
    
    title: "Best flowers for inside home",
    describe:
      "All the flowers are best for your lovely house.Just get the one you love the most",
    imgUrl: "images/Rectangle 64.jpg",
 
  },
  {
   
    title: "Best flowers for inside home",
    describe:
      "All the flowers are best for your lovely house.Just get the one you love the most",
    imgUrl: "images/Rectangle 56.jpg",
    
  },
  {
    
    title: "Best flowers for inside home",
    describe:
      "All the flowers are best for your lovely house.Just get the one you love the most",
    imgUrl: "images/Rectangle 66.jpg",

  },
];

export default posts;
