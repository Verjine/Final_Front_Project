const bestseler = [{
    title: "Daisy",
    price: 5,
    imgUrl: "images/Rectangle 58.jpg",
   
},
{
    title: "Sun flower",
    price: 7,
    imgUrl: "images/Rectangle 58 (1).jpg",
},
{
    title: "White Rose",
    price: 10,
    imgUrl: "images/Rectangle 58 (2).jpg",
  
},
{
    title: "Periwinkle",
    price: 7,
    imgUrl: "images/Rectangle 58 (3).jpg",
}
]


export default bestseler;